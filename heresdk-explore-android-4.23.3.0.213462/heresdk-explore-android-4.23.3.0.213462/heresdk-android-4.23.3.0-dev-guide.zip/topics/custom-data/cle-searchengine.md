## Implementation of the CLESearchEngine

```java
import android.util.Log;

import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.here.common.RESTEngine;
import com.here.sdk.core.GeoCoordinates;
import com.here.sdk.search.SearchError;

import java.util.ArrayList;
import java.util.List;

// A class to initate a proximity search for POIs uploaded to the HERE Fleet Telematics backend.
public class CLESearchEngine {

    private static final String TAG = CLESearchEngine.class.getName();

    private final String apiKey;
    private final RESTEngine restEngine;

    /**
     * The SearchResultCallback interface defines a callback method to handle the results of a search operation
     * done on the FT backend.
     */
    public interface SearchResultCallback {

        /**
         * Called when the search operation has completed, providing the results of the operation.
         *
         * @param searchError An instance of {@link SearchError} containing details about any error
         *                    encountered during the search operation. This is null if the operation
         *                    completed successfully without any errors.
         * @param pois        A list of {@link CLEPoi} objects representing the Points of Interest (POI) found
         *                    during the search operation. This list is null when searchError is not null.
         */
        void onResult(@Nullable SearchError searchError, @Nullable List<CLEPoi> pois);
    }

    public CLESearchEngine(String apiKey) {
        this.apiKey = apiKey;
        restEngine = new RESTEngine();
    }

    public void search(GeoCoordinates searchCenter, int searchRadiusInMeters, String layerName, SearchResultCallback callback) {
        // The URL to create a REST API call to the Fleet Telematics backend.
        String urlStr = "https://smap.hereapi.com/v8/maps/attributes?" +
                "layers=" + layerName +
                "&mapName=MY_STORES" +
                "&geom=local&in=proximity:" + mergeLatLonToString(searchCenter) +
                ";r=" + searchRadiusInMeters +
                "&apiKey=" + apiKey;

        restEngine.initiateGETRequest(urlStr, new RESTEngine.ResultCallback() {
            @Override
            public void onResult(int httpStatus, @Nullable RESTEngine.RESTEngineError error, @Nullable String jsonString) {
                if (error != null) {
                    Log.e(TAG, "Error: " + error.name());
                    Log.e(TAG, "HTTP status code: " + httpStatus);
                    List<CLEPoi> pois = null;
                    callback.onResult(SearchError.HTTP_ERROR, pois);
                    return;
                }

                parseJsonResponse(jsonString, callback);
            }
        });
    }

    private String mergeLatLonToString(GeoCoordinates geoCoordinates) {
        return geoCoordinates.latitude + "," + geoCoordinates.longitude;
    }

    private void parseJsonResponse(String json, SearchResultCallback callback) {
        Log.d(TAG, json);

        Gson gson = new Gson();
        CLEResponse root = gson.fromJson(json, CLEResponse.class);

        SearchError searchError;
        List<CLEPoi> finalPois;

        if (isGeometriesEmpty(root)) {
            searchError = SearchError.NO_RESULTS_FOUND;
            finalPois = null;
        } else {
            searchError = null;
            finalPois = extractPoiData(root);
        }

        callback.onResult(searchError, finalPois);
    }

    private boolean isGeometriesEmpty(CLEResponse root) {
        return root == null || root.geometries == null || root.geometries.isEmpty();
    }

    // Adapt the parsing based on how you have defined your data.
    private List<CLEPoi> extractPoiData(CLEResponse root) {
        List<CLEPoi> nameAndGeometries = new ArrayList<>();
        if (root != null && root.geometries != null) {
            for (CLEGeometry geometry : root.geometries) {
                if (geometry != null && geometry.attributes != null) {
                    nameAndGeometries.add(new CLEPoi(geometry.attributes.NAME, extractCoordinates(geometry.geometry)));
                }
            }
        }
        return nameAndGeometries;
    }

    private List<GeoCoordinates> extractCoordinates(String geometryString) {
        List<GeoCoordinates> coordinatesList = new ArrayList<>();

        // Removing 'MULTIPOLYGON(((' and ')))'.
        String polygonString = geometryString.replace("MULTIPOLYGON(((", "").replace(")))", "");

        // Splitting into coordinate pairs.
        String[] coordinatePairs = polygonString.split(",");

        // Processing each pair.
        for (String pair : coordinatePairs) {
            String[] latLong = pair.trim().split(" ");
            // Note that in the uploaded data longitude is listed first.
            double longitude = Double.parseDouble(latLong[0]);
            double latitude = Double.parseDouble(latLong[1]);
            coordinatesList.add(new GeoCoordinates(latitude, longitude));
        }

        return coordinatesList;
    }
}
```
