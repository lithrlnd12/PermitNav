## Implementation of the RESTEngine

```java
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

// A general purpose engine to initiate a call to a REST API that provides JSON response.
// It is supporting GET requests, but can be also extended to support POST requests, when needed.
public class RESTEngine {

    private static final String TAG = RESTEngine.class.getName();

    public static final int HTTP_STATUS_OK = 200;
    public static final int HTTP_STATUS_UNSET = -1;

    public enum RESTEngineError {
        HTTP_ERROR,
        URL_PARSING_ERROR,
        OPEN_CONNECTION_ERROR,
        PROTOCOL_ERROR,
        RESPONSE_CODE_ERROR,
        STREAM_READING_ERROR,
        STREAM_CLOSING_ERROR
    }

    /**
     * The {@code ResultCallback} interface is used for defining a callback method
     * that handles results in the form of a JSON string.
     */
    public interface ResultCallback {

        /**
         * Called when a result is available. As it is common for the HERE SDK, we notify on the main thread.
         *
         * @param httpStatus A numeric value indicating the HTTP status code as returned by the server.
         *                   If it is != HTTP_STATUS_OK, then error and jsonString are not null.
         * @param error      An error indicating what went wrong. If it is HTTP_ERROR, then check the httpStatus.
         *                   If it is null, then the jsonString is not null and httpStatus = HTTP_STATUS_OK.
         * @param jsonString A JSON string representing the result when HTTP_STATUS_OK.
         *                   This is null when httpStatus != HTTP_OK and error is not null.
         */
        void onResult(int httpStatus, @Nullable RESTEngineError error, @Nullable String jsonString);
    }

    public void initiateGETRequest(String urlStr, ResultCallback callback) {
        // Run on background thread.
        new Thread(() -> executeRequest(urlStr, callback)).start();
    }

    private void executeRequest(String urlStr, ResultCallback callback) {
        int httpStatus = HTTP_STATUS_UNSET;
        String jsonString = null;
        URL url;
        try {
            url = new URL(urlStr);
        } catch (MalformedURLException e) {
            notify(httpStatus, RESTEngineError.URL_PARSING_ERROR, e, jsonString, callback);
            return;
        }

        HttpURLConnection con;
        try {
            con = (HttpURLConnection) url.openConnection();
        } catch (IOException e) {
            notify(httpStatus, RESTEngineError.OPEN_CONNECTION_ERROR, e, jsonString, callback);
            return;
        }

        try {
            con.setRequestMethod("GET");
        } catch (ProtocolException e) {
            notify(httpStatus, RESTEngineError.PROTOCOL_ERROR, e, jsonString, callback);
            return;
        }

        try {
            httpStatus = con.getResponseCode();
        } catch (IOException e) {
            notify(httpStatus, RESTEngineError.RESPONSE_CODE_ERROR, e, jsonString, callback);
            return;
        }

        if (httpStatus != HTTP_STATUS_OK) {
            Exception e = null;
            notify(httpStatus, RESTEngineError.HTTP_ERROR, e, jsonString, callback);
            con.disconnect();
            return;
        }

        BufferedReader in;
        StringBuilder content;
        try {
            in = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String inputLine;
            content = new StringBuilder();

            while (true) {
                if (!((inputLine = in.readLine()) != null)) break;
                content.append(inputLine);
            }
        } catch (IOException e) {
            notify(httpStatus, RESTEngineError.STREAM_READING_ERROR, e, jsonString, callback);
            return;
        }

        try {
            in.close();
        } catch (IOException e) {
            notify(httpStatus, RESTEngineError.STREAM_CLOSING_ERROR, e, jsonString, callback);
            return;
        }

        con.disconnect();

        RESTEngineError error = null;
        Exception e = null;
        jsonString = content.toString();
        notify(httpStatus, error, e, jsonString, callback);
    }

    private void notify(int status, @Nullable RESTEngineError error, @Nullable Exception e, @Nullable String jsonString, ResultCallback callback) {
        Log.d(TAG, "HTTP status code: " + status);

        if (error != null) {
            Log.e(TAG, error.name());
        }

        if (e != null) {
            Log.e(TAG, e.getMessage());
        }

        // As it is common for the HERE SDK, we notify on the main thread.
        new Handler(Looper.getMainLooper()).post(() -> callback.onResult(status, error, jsonString));
    }
}
```
